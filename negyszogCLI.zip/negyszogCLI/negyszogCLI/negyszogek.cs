﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace negyszogCLI
{
    class Negyszog
    {
        public Negyszog(string sor)
        {
            string [] t = sor.Split(' ');
            A = int.Parse(t[0]);
            B = int.Parse(t[1]);
            C = int.Parse(t[2]);
            D = int.Parse(t[3]);

        }

        public int A { get; private set; }
        public int B { get; private set; }
        public int C { get; private set; }
        public int D { get; private set; }


    }
}
