﻿namespace negyszogCLI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Negyszog> negyszogek = new List<Negyszog>();
            List<Negyszog> paralelogrammak = new List<Negyszog>();
            List<Negyszog> rombuszok = new List<Negyszog>();
            List<Negyszog> szerkeszhetok = new List<Negyszog>();

            StreamReader reader = new StreamReader("negyszogek.csv");

            while (!reader.EndOfStream)
            {
                negyszogek.Add(new Negyszog(reader.ReadLine()));
            }

            Console.WriteLine("Négyszögek adatai: ");
            for (int i = 0; i < negyszogek.Count; i++)
            {
                Console.WriteLine($"a: {negyszogek[i].A} b: {negyszogek[i].B} c: {negyszogek[i].C} d: {negyszogek[i].D}");
                if (Paralelogramma(negyszogek[i]))
                {
                    paralelogrammak.Add(negyszogek[i]);
                }
                if (Rombusz(negyszogek[i]))
                {
                    rombuszok.Add(negyszogek[i]);
                }
                if (Szerkesztheto(negyszogek[i]))
                {
                    szerkeszhetok.Add(negyszogek[i]);
                }
            }
                Console.WriteLine("Paralelogrammák: ");
            for (int i = 0; i < paralelogrammak.Count; i++)
            {
                Console.WriteLine($"a: {paralelogrammak[i].A} b: {paralelogrammak[i].B} c: {paralelogrammak[i].C} d: {paralelogrammak[i].D}");
            }
            Console.WriteLine("Rombuszok: ");
            for (int i = 0; i < rombuszok.Count; i++)
            {
                Console.WriteLine($"a: {rombuszok[i].A} b: {rombuszok[i].B} c: {rombuszok[i].C} d: {rombuszok[i].D}");
            }
            Console.WriteLine("Szerkeszthető: ");
            for (int i = 0; i < szerkeszhetok.Count; i++)
            {
                Console.WriteLine($"a: {szerkeszhetok[i].A} b: {szerkeszhetok[i].B} c: {szerkeszhetok[i].C} d: {szerkeszhetok[i].D}");
            }

            Console.ReadKey();
        }

        public static bool Szerkesztheto(Negyszog negyszog)
        {
            return (negyszog.A + negyszog.B + negyszog.C > negyszog.D) &&
           (negyszog.A + negyszog.B + negyszog.D > negyszog.C) &&
           (negyszog.A + negyszog.C + negyszog.D > negyszog.B) &&
           (negyszog.B + negyszog.C + negyszog.D > negyszog.A);
        }

        public static bool Paralelogramma(Negyszog negyszog)
        {
            if (negyszog.A == negyszog.C && negyszog.B == negyszog.D)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool Rombusz(Negyszog negyszog)
        {
            if ((negyszog.A+negyszog.B+negyszog.C+negyszog.D) == negyszog.A*4)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
