﻿namespace BalatonCLI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Utcak> utcak = new List<Utcak>();
            List<Utcak> A = new List<Utcak>();
            List<Utcak> B = new List<Utcak>();
            List<Utcak> C = new List<Utcak>();



            StreamReader reader = new StreamReader("utca.txt");
            reader.ReadLine();

            while (!reader.EndOfStream)
            {
                utcak.Add(new Utcak(reader.ReadLine()));
            }

            Console.WriteLine($"2. Feladat. A mintában {utcak.Count} telek szerepel.");


            Feladat3(utcak);

            foreach (var item in utcak)
            {
                if (item.adosav =="A")
                {
                    A.Add(item);
                }
                if (item.adosav == "B")
                {
                    B.Add(item);
                }
                if (item.adosav == "C")
                {
                    C.Add(item);
                }
            }
            int Aado = 0;
            foreach (var item in A)
            {
                Aado = Aado + Ado(item);
            }
            int Bado = 0;
            foreach (var item in B)
            {
                Bado = Bado + Ado(item);
            }
            int Cado = 0;
            foreach (var item in C)
            {
                if (Ado(item) < 10000)
                {
                    Cado = Cado + 0;
                }
                else
                {
                    Cado = Cado + Ado(item);
                }
            }
            Console.WriteLine($"Az A sávba {A.Count} telek esik, az adó {Aado} Ft");
            Console.WriteLine($"A B sávba {B.Count} telek esik, az adó {Bado} Ft");
            Console.WriteLine($"A C sávba {C.Count} telek esik, az adó {Cado} Ft");

            Console.ReadKey();




        }
        public static int Ado(Utcak utca)
        {
            
                if (utca.adosav =="A")
                {
                    return utca.alapterulet * 800;
                }
                if (utca.adosav == "B")
                {
                    return utca.alapterulet * 600;
                }
                if (utca.adosav == "C")
                {
                
                    return utca.alapterulet * 100;
                }
                else
                {
                    return 100;
                }
                
            }
  

        private static void Feladat3(List<Utcak> utcak)
        {
            Console.WriteLine("Adja meg a tulajdonos adószámát!");
            int bekertado = int.Parse(Console.ReadLine());
            Console.WriteLine($"A tulajdonos adószáma: {bekertado}");

            foreach (var item in utcak)
            {
                if (item.adoszam == bekertado)
                {
                    Console.WriteLine($"{item.utcaneve} utca {item.hazszam}");

                }
                
            }

            Console.ReadKey();
        }
    }
}
