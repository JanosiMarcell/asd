﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalatonCLI
{
    class Utcak
    {
        public Utcak(string sor)
        {
            string[] t = sor.Split(' ');
            adoszam = int.Parse(t[0]);
            utcaneve = t[1];
            hazszam = t[2];
            adosav = t[3];
            alapterulet = int.Parse(t[4]);
        }

        public Utcak(int adoszam, string utcaneve, string hazszam, string adosav, int alapterulet)
        {
            this.adoszam = adoszam;
            this.utcaneve = utcaneve;
            this.hazszam = hazszam;
            this.adosav = adosav;
            this.alapterulet = alapterulet;
        }

        public int adoszam { get; private set; }
        public string utcaneve { get; private set; }
        public string hazszam { get; private set; }
        public string adosav { get; private set; }
        public int alapterulet { get; private set; }


    }
}
